﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Maze_Test
{    
    public class Maze4Form
    {
        private IMaze _mazeTiles;

        public Maze4Form(IMaze mazeTiles)
         {
             this._mazeTiles = mazeTiles;
        }
        public PictureBox[,] Create()
        {            
            return this._mazeTiles.Create();           
        }
        public bool Solve(int xPos, int yPos, bool[,] alreadySearched)
        {
            return this._mazeTiles.Solve(xPos,yPos,alreadySearched);
        }
    }
}
