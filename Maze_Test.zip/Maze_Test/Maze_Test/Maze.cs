﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Maze_Test
{
    public interface IMaze
    {
        PictureBox[,] Create();
        bool Solve(int xPos, int yPos, bool[,] alreadySearched);
    }

    public class Maze : IMaze
    {
        private int XTILES = 25; //Number of X tiles
        private int YTILES = 25; //Number of Y tiles
        private int TILESIZE = 15; //Size of the tiles (pixles)
        private PictureBox[,] mazeTiles;

        public PictureBox[,] Create()
        {
            mazeTiles = new PictureBox[XTILES, YTILES];

            //Loop for getting all tiles
            for (int i = 0; i < XTILES; i++)
            {
                for (int j = 0; j < YTILES; j++)
                {
                    //initialize a new PictureBox array at cordinate XTILES, YTILES
                    mazeTiles[i, j] = new PictureBox();

                    //calculate size and location
                    int xPosition = (i * TILESIZE) + 13; //13 is padding from left
                    int yPosition = (j * TILESIZE) + 45; //45 is padding from top
                    mazeTiles[i, j].SetBounds(xPosition, yPosition, TILESIZE, TILESIZE);
                }
            }
            return mazeTiles;
        }

        public bool Solve(int xPos, int yPos, bool[,] alreadySearched)
        {
            bool correctPath = false;            
            bool shouldCheck = true;

            //Check for out of boundaries
            if (xPos >= XTILES || xPos < 0 || yPos >= YTILES || yPos < 0)
                shouldCheck = false;
            else
            {
                //Check if at finish, not (0,0 and colored Yellow)
                if (mazeTiles[xPos, yPos].BackColor == Color.Yellow && (xPos != 0 && yPos != 0))
                {
                    correctPath = true;
                    shouldCheck = false;
                }

                //Check for a wall
                if (mazeTiles[xPos, yPos].BackColor == Color.Black)
                    shouldCheck = false;

                //Check if previously searched
                if (alreadySearched[xPos, yPos])
                    shouldCheck = false;
            }

            //Search the Tile
            if (shouldCheck)
            {
                //mark tile as searched
                alreadySearched[xPos, yPos] = true;

                //Check right tile
                correctPath = correctPath || Solve(xPos + 1, yPos, alreadySearched);
                //Check down tile
                correctPath = correctPath || Solve(xPos, yPos + 1, alreadySearched);
                //check left tile
                correctPath = correctPath || Solve(xPos - 1, yPos, alreadySearched);
                //check up tile
                correctPath = correctPath || Solve(xPos, yPos - 1, alreadySearched);
            }

            //make correct path gray
            if (correctPath)
                mazeTiles[xPos, yPos].BackColor = Color.Gray;

            return correctPath;
        }
    }
}
