﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Maze_Test
{
    public partial class Form1 : Form
    {
        Color currentColor = Color.White;
        private int XTILES = 25; //Number of X tiles
        private int YTILES = 25; //Number of Y tiles        
        private PictureBox[,] _mazeTiles;       
        
        Maze4Form newMaze = new Maze4Form(new Maze());        

        public Form1()
        {
            InitializeComponent();
            _mazeTiles = newMaze.Create();
            this.applyEvents();
        }

        private void applyEvents()
        {          
            //Loop for getting all tiles
            for (int i = 0; i < XTILES; i++)
            {
                for (int j = 0; j < YTILES; j++)
                {
                    //make top left and right bottom corner Yellow. Used for start and finish
                    if ((i == 0 && j == 0) || (i == XTILES - 1 && j == YTILES - 1))
                        _mazeTiles[i, j].BackColor = Color.Yellow;       
                    else                          
                    {
                        //make all other tiles white
                        _mazeTiles[i, j].BackColor = Color.White;
                        //make it clickable
                        EventHandler clickEvent = new EventHandler(PictureBox_Click);
                        _mazeTiles[i, j].Click += clickEvent; // += used incase other events are used

                        MouseEventHandler mousemoveEvent = new MouseEventHandler(PictureBox_MouseMove);
                        _mazeTiles[i, j].MouseMove += mousemoveEvent; // += used incase other events are used

                    }
                    //Add to controls to form (display picture box)
                    this.Controls.Add(_mazeTiles[i, j]);
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            currentColor = Color.White;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            currentColor = Color.Black;
        }

        private void PictureBox_Click(object sender, EventArgs e)
        {
            ((PictureBox)sender).BackColor = currentColor;
        }

        private void PictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            label3.Text = "XPosition: " + e.Location.X + "  " + "YPosition: " + e.Location.Y;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Create a previously searched array
            bool[,] alreadySearched = new bool[XTILES,YTILES];

            //Starts the recursive solver at tile (0,0). 
            if (!newMaze.Solve(0, 0, alreadySearched))
                MessageBox.Show("Maze can not be solved.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Change all greay tiles to white
            for (int i = 0; i < XTILES; i++)
            {
                for (int j = 0; j < YTILES; j++)
                {
                    if (_mazeTiles[i, j].BackColor == Color.Gray)
                        _mazeTiles[i, j].BackColor = Color.White;
                }
            }

            //Reset start and finish to yello
            _mazeTiles[0, 0].BackColor = Color.Yellow;
            _mazeTiles[XTILES - 1, YTILES - 1].BackColor = Color.Yellow;
        }

      
    }
}
